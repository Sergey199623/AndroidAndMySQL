<?php
 
define('DB_USER', "devcol_test"); // db user
define('DB_PASSWORD', "zuif1b3e"); // db password 
define('DB_DATABASE', "devcol_test"); // database name
define('DB_SERVER', "localhost"); // db server
?>